package com.ubk.bank.money.transfer.controller;


import com.ubk.bank.money.transfer.models.*;
import com.ubk.bank.money.transfer.service.AccountService;
import com.ubk.bank.money.transfer.service.CoreTransferService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1")
public class MoneyTransferController {

    @Autowired
    private AccountService accountService;

    @Autowired
    private CoreTransferService coreTransferService;

    @Value("${max.transaction.limit}")
    private int transactionLimit;

    @Value("${max.digits.cif}")
    private int cifLimit;

    @Value("${max.digits.accountNumber}")
    private int accountNumberLimit;

    @Value("${max.digits.iban}")
    private int ibanLimit;

    @RequestMapping(method = RequestMethod.POST, produces = "application/json")
    public ResponseEntity<AccountResponse> getAccount(@RequestBody AccountRequest request) {
        AccountResponse response = new AccountResponse();

        try {
            AccountDto accountDTO = accountService.getAccountByNumber(request.getCif(), request.getSourceAccount());

            if (CustomValidator.validationForTransfer(accountDTO, request, cifLimit, accountNumberLimit, ibanLimit)) {
                TransferRequestDto transferRequest = new TransferRequestDto();
                TransferRequestDto.DebitLeg debitLeg = new TransferRequestDto.DebitLeg();
                TransferRequestDto.CreditLeg creditLeg = new TransferRequestDto.CreditLeg();
                debitLeg.setAccount(request.getSourceAccount());
                debitLeg.setCurrency(request.getCurrency());
                debitLeg.setAmount(request.getAmount());
                creditLeg.setAccount(request.getDestinationAccount());
                transferRequest.setCreditLeg(creditLeg);
                transferRequest.setDebitLeg(debitLeg);
                transferRequest.setReason(request.getReason());
                transferRequest.setNotes(request.getNotes());
                transferRequest.setTransactionNumber(CustomValidator.generateRandomNumber(transactionLimit));
                response = coreTransferService.transferMoney(transferRequest);
                return new ResponseEntity<>(response, HttpStatus.valueOf("OK"));
            }
            Data data = new Data();
            data.setTimestamp(LocalDateTime.now().toString());
            data.setTransactionStatus("FAILED");
            response.setStatus("SUCCESS");
            response.setData(data);
            return new ResponseEntity<>(response, HttpStatus.ACCEPTED);
        }
        catch(Exception e){
            response.setStatus("error");
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }




}
