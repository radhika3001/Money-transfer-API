package com.ubk.bank.money.transfer.service;

import com.ubk.bank.money.transfer.models.AccountResponse;
import com.ubk.bank.money.transfer.models.Data;
import com.ubk.bank.money.transfer.models.TransferRequestDto;
import com.ubk.bank.money.transfer.models.TransferResponseDto;
import com.ubk.bank.money.transfer.utils.ExternalBankServiceClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Random;

@Service
public class CoreTransferService {

    @Autowired
    private ExternalBankServiceClient externalBankServiceClient;

    @Value("max.transaction.limit")
    private static int transactionLimit;


    private static final Random RANDOM = new Random();

    public static String generateTransactionId() {

        StringBuilder transactionId = new StringBuilder();
        for (int i = 0; i < transactionLimit; i++) {
            transactionId.append(RANDOM.nextInt(10)); // Append a random digit
        }
        return transactionId.toString();
    }

    public AccountResponse transferMoney(TransferRequestDto request) {
        request.setTransactionNumber(generateTransactionId());
        TransferResponseDto response = externalBankServiceClient.transferMoney(request);
        AccountResponse finalResponse = new AccountResponse();
        finalResponse.setStatus(response.getStatus());
        Data data = new Data();
        data.setTimestamp(String.valueOf(LocalDateTime.now()));
        data.setTransactionNumber(request.getTransactionNumber());
        data.setTransactionStatus("SUCCESS");
;        finalResponse.setData(data);
        return finalResponse;
    }

}
